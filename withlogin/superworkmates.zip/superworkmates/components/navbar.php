  <div class="superline">
  <h3> Do you you see someone excellent in his work? He/She will stand before kings! Prov. 22:29 </h3>
  </div>

<div class="navbar">
          <div class="navlink navlink-hamburger">  <a href="#">&#9776</a> </div>
          <div class="navlink">  <a href="index.php"> Home </a> </div>
          <div class="navlink">  <a href="myOffice.php"> My Office </a> </div>
          <div class="navlink">  <a href="trends.php">Trends </a> </div>
           <!--<div class="navlink"> <a href="projects.php"> Projects </a> </div>
          <div class="navlink">  <a href="my-workermates.html">  My Workmates </a> </div>
          <div class="navlink"> <a href="equipment"> Tools and Equipment </a> </div>
          <div class="navlink"> <a href="collaborates.php"> Collaborate </a> </div>
          <div class="navlink"> <a href="educations.php"> Learn </a> </div>
           <div class="navlink"> <a href="forums.php"> Forums </a> </div>-->
          <!--<div class="navlink"> <a href="outings.php"> Outings </a> </div>-->
          <div class="navlink"> <a href="about.php"> About Us</a>  </div>
</div>