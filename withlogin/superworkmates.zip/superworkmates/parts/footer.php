<div class="footer">
      <footer>
        <div class="fmission">
           <p class="mtitle">Mission:</p> 
           <p>To provide the <strong>place</strong> where <strong>together</strong> we exploit the <strong>power</strong> in us to make a better world.</p>
        </div>
        <div class="f2">
          <div class="f2p1">
            <a href="https://facebook.com" target="_blank"> <p><div class="f2a">Facebook</div></p> </a>
            <a href="https://twitter.com" target="_blank"> <p><div class="f2a">Twitter</div></p> </a>
            <a href="https://instagram.com" target="_blank"> <p><div class="f2a">Instagram</div></p> </a>
            <a href="https://youtube.com" target="_blank"> <p><div class="f2a">YouTube</div></p> </a>
            <a href="https://linkedin.com" target="_blank"> <p><div class="f2a">LinkedIn</div></p> </a>
            <p> <div class="f2a"> WhatsApp : +254 729 515 273 </div> </p>
          </div>

          <div class="f2p2">
            <p>First Made</p>
            <p>@</p>
            <p>Climax Electronics & Cyber, Ngorika</p>
            <p>Nyandarua County, Kenya</p>
            <p>By</p>
            <p>Joseph Njenga, Joel Njoroge W. & Team</p>
          </div>

          <div class="f2p3">
            <p>Email: <a href="mailto: support@superworkmates.com">support@superworkmates.com</a></p>
            <p>Phone:</p>
            <p>Phone:</p>
            <p>P.O BOX 14073</p>
            <p>Nakuru</p>
          </div>

        </div>
      
      <hr/>

        <div class="f3">
           <p> &copy; Superworkmates 2020 </p>
           <p>You Don't Have To Work Alone!</p>
            
        </div>
      </footer>
    </div>
<!-- scripts -->
<script src="bootstrap/jquery/jquery-3.2.1.min.js"></script>
<script src="bootstrap/js/bootstrap.min.js"></script>
  </body>
</html>