<?php
//opens connection to mysql server
$dbc = mysql_connect ($username);


 ?>
