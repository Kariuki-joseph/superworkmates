<?php
define('HOST_NAME', 'localhost');
define('USER', 'root');
define('PASS', '');
define('DB_NAME', 'superworkmates');
?>
