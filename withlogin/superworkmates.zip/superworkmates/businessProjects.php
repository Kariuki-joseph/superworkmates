<?php
include('components/header.php');
include('components/navBar.php');
?>
<div class="row">
	<div class="col-sm-6">

<!--business Project-->
<div class="projects-wrapper">
<div class="project-title"></div><!--also include the title of the author-->
<div class="project-image">
	<div class="project-timeline"></div>
</div>
<div class="project-aim"></div>
<div class="project-description"></div>
<div class="project-requirements"></div>
<div class="project-market"></div>
<div class="project-suppliers"></div>
<div class="project-products"></div>
<div class="project-pricing"></div>
<div class="project-profit"></div>
<div class="project-hr"></div>
<div class="project-competition"></div>
<div class="project-policies"></div>

</div>
<!--business Project-->

</div>
<div class="col-sm-6"></div>
</div>